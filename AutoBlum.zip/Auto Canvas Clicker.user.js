// ==UserScript==
// @name         Auto Canvas Clicker
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description  Continuously clicks on the game canvas
// @author       You
// @match        https://app.tg.vooi.io/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to click the specific SVG element
    function clickSpecificSVG() {
        // Select the specific SVG element using a more precise selector
        const svgElement = document.querySelector('svg[fill="none"][viewBox="0 0 20 20"]'); // Adjust this selector if necessary

        if (svgElement) {
            svgElement.click();  // Simulate a click on the SVG
            console.log('SVG clicked!'); // Log successful click
        } else {
            console.log('Specific SVG not found.'); // Log if SVG is not found
        }
    }

    // Function to keep trying to click the SVG
    function attemptClick() {
        const svgElement = document.querySelector('svg[fill="none"][viewBox="0 0 20 20"]');
        if (svgElement) {
            clickSpecificSVG();
        } else {
            console.log('SVG not available yet, retrying...');
        }
    }

    // Wait for the DOM to fully load
    window.addEventListener('load', () => {
        // Call the click function every second
        setInterval(attemptClick, 1000);  // Adjust the interval as necessary
    });
})();
