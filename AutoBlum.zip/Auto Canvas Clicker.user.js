// ==UserScript==
// @name         Auto Canvas Clicker
// @namespace    http://tampermonkey.net/
// @version      0.3
// @description  Continuously clicks on the game canvas
// @author       You
// @match        https://app.tg.vooi.io/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to get random coordinates within the canvas
    function getRandomCoordinates(canvas) {
        const rect = canvas.getBoundingClientRect();
        const x = Math.floor(Math.random() * rect.width);
        const y = Math.floor(Math.random() * rect.height);
        return { x, y };
    }

    // Function to click at a random position on the canvas
    function clickOnCanvas() {
        const canvas = document.querySelector('canvas'); // Adjust this selector if needed
        if (!canvas) return;

        const { x, y } = getRandomCoordinates(canvas);

        // Create a mouse event to simulate clicking
        const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: rect.left + x,
            clientY: rect.top + y
        });

        canvas.dispatchEvent(clickEvent);
        console.log(`Clicked on canvas at (${x}, ${y})`);
    }

    // Run the function continuously to click on the canvas
    setInterval(clickOnCanvas, 100); // Adjust the interval as needed
})();
